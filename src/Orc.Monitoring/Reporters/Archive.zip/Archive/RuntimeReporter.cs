﻿#pragma warning disable CTL0011
namespace Gum.Projects.Data.Performance.Reporters.Archive;

using System;
using System.Collections.Generic;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Reflection;
using Catel.Logging;
using MethodLifeCycleItems;
using ReportOutputs;

public class RuntimeReporter : IMethodCallReporter
{
    private static readonly ILog Log = LogManager.GetCurrentClassLogger();

    private const string LogPrefix = "[PerformanceMonitor] ";

    private readonly List<IReportOutput> _outputs = new();

    private MethodInfo _rootMethod;

    public void OnNext(IMethodLifeCycleItem value)
    {
        var lineContent = value switch
        {
            MethodCallStart methodCallStart =>
                $"Start method: Thread {methodCallStart.ThreadId}:{methodCallStart.MethodCallInfo.Id} {methodCallStart.MethodCallInfo.MethodName} (start: {methodCallStart.TimeStamp:HH:mm:ss.fff})",

            MethodCallEnd methodCallEnd =>
                $"End method: Thread {methodCallEnd.ThreadId}: {methodCallEnd.MethodCallInfo.Id} {methodCallEnd.MethodCallInfo.MethodName} (duration: {methodCallEnd.MethodCallInfo.Elapsed.TotalMilliseconds:N1} ms)",

            MethodCallException methodCallException =>
                $"Exception: Thread {methodCallException.ThreadId}: {methodCallException.MethodCallInfo.Id} {methodCallException.MethodCallInfo.MethodName} (exception: {methodCallException.Exception.Message})",

            LogEntryItem logEntryItem =>
                $"Update: Thread {logEntryItem.ThreadId}: {logEntryItem.MethodCallInfo.Id} {logEntryItem.MethodCallInfo.MethodName} ({logEntryItem.Category} = '{logEntryItem.Data}')",

            _ => string.Empty
        };

        Log.Info($"{LogPrefix} Runtime report: {lineContent}");
    }

    public string Name { get => "Runtime Report"; }
    public string FullName => Name;

    public MethodInfo RootMethod
    {
        get => _rootMethod;
        set => _rootMethod = value;
    }

    public IDisposable StartReporting(IObservable<ICallStackItem> callStack)
    {
        if (_rootMethod is null)
        {
            throw new InvalidOperationException("Unable to start reporting when root method is not set");
        }

        var compositeDisposable = new CompositeDisposable();

        compositeDisposable.Add(InitializeOutputs());

        var filteredStream = callStack.OfType<IMethodLifeCycleItem>()
                .SkipWhile(x => !(x is MethodCallStart && Equals(x.MethodCallInfo.MethodInfo, _rootMethod)))
                .TakeUntil(x => x is MethodCallEnd && Equals(x.MethodCallInfo.MethodInfo, _rootMethod));

        compositeDisposable.Add(filteredStream.OfType<IMethodLifeCycleItem>().Subscribe(OnNext));

        return compositeDisposable;
    }

    private IDisposable InitializeOutputs()
    {
        var compositeDisposable = new CompositeDisposable();

        foreach (var reportOutput in _outputs)
        {
            compositeDisposable.Add(reportOutput.Initialize(this));
        }

        return compositeDisposable;
    }

    public IOutputContainer AddOutput<TOutput>(object parameter) where TOutput : IReportOutput, new()
    {
        var output = new TOutput();
        output.SetParameters(parameter);

        _outputs.Add(output);

        return this;
    }
}
