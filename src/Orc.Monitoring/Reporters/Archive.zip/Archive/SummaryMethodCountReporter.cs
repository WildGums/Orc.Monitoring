﻿#pragma warning disable CTL0011
namespace Gum.Projects.Data.Performance.Reporters.Archive;

using System.Collections.Generic;
using System.Text;
using System;
using System.Linq;
using Catel.Logging;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Reflection;
using MethodLifeCycleItems;
using ReportOutputs;

/// <summary>
/// Generates a full report of the method calls.
/// </summary>
public sealed class SummaryMethodCountReporter : IMethodCallReporter
{
    private static readonly ILog Log = LogManager.GetCurrentClassLogger();

    private const string LogPrefix = "[PerformanceMonitor] ";

    private readonly List<IMethodLifeCycleItem> _items = new();
    private readonly List<IReportOutput> _outputs = new();

    private MethodInfo _rootMethod;

    public string Name { get => "Summary Method Count Report"; }
    public string FullName => Name;

    public MethodInfo RootMethod
    {
        get => _rootMethod;
        set => _rootMethod = value;
    }

    public IDisposable StartReporting(IObservable<ICallStackItem> callStack)
    {
        if (_rootMethod is null)
        {
            throw new InvalidOperationException("Unable to start reporting when root method is not set");
        }

        var compositeDisposable = new CompositeDisposable();

        compositeDisposable.Add(InitializeOutputs());

        var appendItems = callStack.OfType<IMethodLifeCycleItem>().Subscribe(onNext: _items.Add);
        var publishSummary = callStack.Where(x => Equals(x, CallStackItem.Empty)).Subscribe(x => Publish());

        compositeDisposable.Add(appendItems);
        compositeDisposable.Add(publishSummary);

        return compositeDisposable;
    }

    private IDisposable InitializeOutputs()
    {
        var compositeDisposable = new CompositeDisposable();

        foreach (var reportOutput in _outputs)
        {
            compositeDisposable.Add(reportOutput.Initialize(this));
        }

        return compositeDisposable;
    }

    public IOutputContainer AddOutput<TOutput>(object parameter = null) where TOutput : IReportOutput, new()
    {
        var output = new TOutput();
        output.SetParameters(parameter);

        _outputs.Add(output);

        return this;
    }

    private void Publish()
    {
        var items = _items.ToList();
        _items.Clear();

        var methodLifeCycleItems = items.Where(x => x is MethodCallStart).ToList();
        var methodCallContextsWithUniqueName = methodLifeCycleItems.Select(x => x.MethodCallInfo).DistinctBy(y => y.MethodName);
        var methodCallsDictionary = new Dictionary<MethodCallInfo, int>();
        foreach (var methodCallInfo in methodCallContextsWithUniqueName)
        {
            var itemsCallCount = methodLifeCycleItems.Select(x => x.MethodCallInfo).Count(x => x.MethodName == methodCallInfo.MethodName);
            methodCallsDictionary[methodCallInfo] = itemsCallCount;
        }

        var sb = new StringBuilder();
        sb.AppendLine("=== Summary Method Count Report ===");
        sb.AppendLine($"Generated at: {DateTime.UtcNow:yyyy-MM-dd HH:mm:ss.fff}");
        sb.AppendLine();

        sb.AppendLine("**Method Call Count Summary:**");
        var contextsByThread = new Dictionary<int, List<MethodCallContext>>();
        foreach (var item in methodCallsDictionary.OrderByDescending(x => x.Value))
        {
            var methodCallInfo = item.Key;

            sb.AppendLine(GenerateCallReport(methodCallInfo, item.Value));
        }

        sb.AppendLine();

        var report = sb.ToString();

        Log.Info($"{LogPrefix}PerformanceMonitor Report:{Environment.NewLine}{report}");

    }

    private string GenerateCallReport(MethodCallInfo methodCallInfo, int count) => $"{LogPrefix} {count} {methodCallInfo.Id} {methodCallInfo.ClassType.Name}.{methodCallInfo.MethodName}";
}
