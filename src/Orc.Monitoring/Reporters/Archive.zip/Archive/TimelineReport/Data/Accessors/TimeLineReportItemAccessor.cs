﻿namespace Gum.Projects.Data.Performance.Reporters.Archive.TimelineReport.Data.Accessors;

using System;
using System.Collections.Generic;
using System.Linq;
using Gum.Projects.Data.Performance.Reporters.Archive.TimelineReport.Models;
using Storage;

internal class TimeLineReportItemAccessor : IEntityAccessor<TimeLineReportItem>
{
    private readonly Dictionary<string, TimeLineReportItemAttributeType> _attributeTypes;

    public TimeLineReportItemAccessor(IReadOnlyCollection<TimeLineReportItemAttributeType> attributeTypes)
    {
        _attributeTypes = attributeTypes.ToDictionary(x => x.Name);
    }

    public TimeLineReportItem CreateInstance() => new();

    public string[] GetHeaderNames() => _attributeTypes.Keys.ToArray();

    public string[] GetPropertyNames() => GetHeaderNames();

    public Type GetPropertyType(string propertyName)
        => _attributeTypes.TryGetValue(propertyName, out var attributeType)
            ? attributeType.Type
            : typeof(object);

    public string GetEntityName() => nameof(TimeLineReportItem);

    public string[] GetIdMembers() => [];

    public Action<TimeLineReportItem, object> GetPropertySetter(string propertyName) =>
        throw new NotImplementedException();

    //TODO:Vladimir too long use Dict
    public Func<TimeLineReportItem, object> GetPropertyGetter(string propertyName)
        => x => x.Attributes.FirstOrDefault(x => Equals(x.Type.Name, propertyName))?.Value;
}
