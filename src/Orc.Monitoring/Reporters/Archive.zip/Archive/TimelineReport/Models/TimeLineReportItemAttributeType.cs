﻿namespace Gum.Projects.Data.Performance.Reporters.Archive.TimelineReport.Models;

using System;

internal class TimeLineReportItemAttributeType
{
    public string Name { get; set; }
    public Type Type { get; set; }
}
