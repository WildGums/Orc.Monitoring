﻿namespace Gum.Projects.Data.Performance.Reporters.Archive.TimelineReport.Models;

using System;
using System.Collections.Generic;

internal class TimeLineReport
{
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
    public IReadOnlyCollection<TimeLineReportItem> Items { get; set; }
    public IReadOnlyCollection<TimeLineReportItemAttributeType> AttributeTypes { get; set; }
}
