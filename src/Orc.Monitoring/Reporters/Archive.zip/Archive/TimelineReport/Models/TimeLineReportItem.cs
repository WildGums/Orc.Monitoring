﻿namespace Gum.Projects.Data.Performance.Reporters.Archive.TimelineReport.Models;

using System;
using System.Collections.Generic;

internal class TimeLineReportItem
{
    public string Id { get; set; }
    public int StartThreadId { get; set; }
    public int EndThreadId { get; set; }
    public string CallerClass { get; set; }
    public string CallerMethod { get; set; }
    public int StartThreadSequence { get; set; }
    public int EndThreadSequence { get; set; }
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }

    public List<TimeLineReportItemAttribute> Attributes { get; } = new();
}
