﻿namespace Gum.Projects.Data.Performance.Reporters.Archive.TimelineReport.Models;

using System;

internal class TimeLineReportItemAttribute
{
    public TimeLineReportItemAttribute(DateTime timeStamp, TimeLineReportItemAttributeType type, object value = null)
    {
        Timestamp = timeStamp;
        Type = type;
        Value = value;
    }

    public TimeLineReportItemAttributeType Type { get; }
    public object Value { get; }
    public DateTime Timestamp { get; }
}
