﻿#pragma warning disable CTL0011
namespace Gum.Projects.Data.Performance.Reporters.Archive.TimelineReport;

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Catel.IoC;
using Catel.Logging;
using Catel.Services;
using Data.Accessors;
using FileSystem;
using Gum.Projects.Data.Performance;
using Gum.Projects.Data.Performance.Reporters;
using MethodLifeCycleItems;
using ReportOutputs;
using Storage.Csv;

/// <summary>
/// Generates a CSV timeline report of the method calls.
/// </summary>
public class TimelineReporter : IMethodCallReporter
{
    private static readonly ILog Log = LogManager.GetCurrentClassLogger();

    private const string RanttProjectContents =
        "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n<Project RanttVersion=\"3.5.0.0\" MinimumRanttVersion=\"2.0\">\r\n  <General Name=\"TimeLineReport\" Description=\"TimeLineReport\" DefaultAttribute=\"Resource\">\r\n    <Culture BaseCulture=\"en-AU\" FirstDayOfWeek=\"Monday\" />\r\n    <DateRange IsEnabled=\"false\" />\r\n    <RefreshInterval IsEnabled=\"false\" Interval=\"0\" UnitOfTime=\"Second\" />\r\n  </General>\r\n  <DataSets>\r\n    <DataSet Name=\"TimeLineReport\">\r\n      <Operations IsEmpty=\"false\" SourceType=\"Csv\" Source=\"%SourceFileName%\" DateRepresentation=\"Absolute\">\r\n        <FieldMappings>\r\n          <FieldMapping From=\"CallerMethod\" To=\"Resource\" />\r\n        </FieldMappings>\r\n      </Operations>\r\n      <CalendarPeriods IsEmpty=\"true\" SourceType=\"Csv\" Source=\"\" DateRepresentation=\"Absolute\">\r\n        <FieldMappings />\r\n      </CalendarPeriods>\r\n      <Relationships IsEmpty=\"true\" SourceType=\"Csv\" Source=\"\" DateRepresentation=\"Absolute\">\r\n        <FieldMappings />\r\n      </Relationships>\r\n    </DataSet>\r\n  </DataSets>\r\n</Project>";

    private readonly List<IReportOutput> _outputs = new();

    private readonly ICsvSaver _csvSaver;

    private readonly string _outputFileName;
    private readonly string _outputFolderPath;
    private readonly bool _supportRantt;

    private MethodInfo _rootMethod;

    public TimelineReporter()
    {

    }

    public TimelineReporter(MethodInfo rootMethod = null)
        : this(new CsvSaver(new FileWrapper()))
    {
        _rootMethod = rootMethod;

        // TODO: IMPORTANT - This is a workaround to get the application data directory, we should refactor this to a better solution
        // TODO: IMPORTANT - we could separate tools for writing into output (CSV, Rantt, Log, etc.)
        // TODO: IMPORTANT - it should be configured in MonitorConfiguration
#pragma warning disable IDISP004
        var appDataService = this.GetServiceLocator().ResolveType<IAppDataService>();
#pragma warning restore IDISP004
        _outputFolderPath = Path.Combine(appDataService.GetApplicationDataDirectory(Catel.IO.ApplicationDataTarget.UserRoaming), "log", "Performance");

        var outputFileName = "Timeline";
        var supportRantt = true;

        _supportRantt = supportRantt;
        _outputFileName = outputFileName.Replace(".csv", string.Empty);
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="TimelineReporter"/> class.
    /// </summary>
    /// <param name="csvSaver">The CSV saver.</param>
    /// <exception cref="ArgumentNullException"><paramref name="csvSaver"/> is <c>null</c>.</exception>
    private TimelineReporter(ICsvSaver csvSaver)
    {
        ArgumentNullException.ThrowIfNull(csvSaver);

        _csvSaver = csvSaver;
    }

    public string Name { get => "Timeline Report"; }
    public string FullName => Name;

    public MethodInfo RootMethod
    {
        get => _rootMethod;
        set => _rootMethod = value;
    }

    public IDisposable StartReporting(IObservable<ICallStackItem> callStack)
    {
        if (_rootMethod is null)
        {
            throw new InvalidOperationException("Unable to start reporting when root method is not set");
        }

        var compositeDisposable = new CompositeDisposable();

        compositeDisposable.Add(InitializeOutputs());

        // Add call stack tracing in DEBUG mode for detailed debugging information.

#if DEBUG
        compositeDisposable.Add(callStack.Trace("Time Line Reporter").Subscribe());
#endif

        var filteredStream = callStack.OfType<IMethodLifeCycleItem>()
            .SkipWhile(x => !(x is MethodCallStart && Equals(x.MethodCallInfo.MethodInfo, _rootMethod)))
            .TakeUntil(x => x is MethodCallEnd && Equals(x.MethodCallInfo.MethodInfo, _rootMethod));

        // Collect items into a list once the stream completes, then process them.
        var subscription = filteredStream.ToList().SubscribeAsync(PublishAsync);

        compositeDisposable.Add(subscription);

        return compositeDisposable;
    }

    private IDisposable InitializeOutputs()
    {
        var compositeDisposable = new CompositeDisposable();

        foreach (var reportOutput in _outputs)
        {
            compositeDisposable.Add(reportOutput.Initialize(this));
        }

        return compositeDisposable;
    }

    public IOutputContainer AddOutput<TOutput>(object parameter) where TOutput : IReportOutput, new()
    {
        var output = new TOutput();
        output.SetParameters(parameter);

        _outputs.Add(output);

        return this;
    }

    private async Task PublishAsync(IList<IMethodLifeCycleItem> items)
    {
        var timeLineReport = new TimeLineReporterBuilder()
            .CreateReport(items);

        var outputDirectory = Path.Combine(_outputFolderPath,
            $"TimeLineReport {timeLineReport.StartTime:yy-MMM-dd HH-mm-ss} - {timeLineReport.EndTime:yy-MMM-dd HH-mm-ss}");
        if (!Directory.Exists(outputDirectory))
        {
            Directory.CreateDirectory(outputDirectory);
        }

        var csvFileName = $"{_outputFileName}.csv";
        var outputFile = Path.Combine(outputDirectory, csvFileName);

        await _csvSaver.SaveFileAsync(outputFile, timeLineReport.Items.OrderBy(x => x.StartTime),
            CultureInfo.CurrentCulture, new TimeLineReportItemAccessor(timeLineReport.AttributeTypes));

        if (_supportRantt)
        {
            var ranttProjectFileName = $"{_outputFileName}.rprjx";

            var ranttProjectContents = RanttProjectContents.Replace("%SourceFileName%", csvFileName);
            var ranttProjectPath = Path.Combine(outputDirectory, ranttProjectFileName);

            await File.WriteAllTextAsync(ranttProjectPath, ranttProjectContents);
        }
    }
}

public static class ObservableExtensions
{
    public static IDisposable SubscribeAsync<T>(this IObservable<T> source, Func<T, Task> asyncAction)
    {
        return source.SelectMany(items => Observable.FromAsync(() => asyncAction(items))).Subscribe();
    }
}

