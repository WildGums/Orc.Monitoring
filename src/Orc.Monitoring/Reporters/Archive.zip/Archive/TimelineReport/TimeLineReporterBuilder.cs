﻿namespace Gum.Projects.Data.Performance.Reporters.Archive.TimelineReport;

using System.Collections.Generic;
using System.Linq;
using Gum.Projects.Data.Performance.Reporters.Archive.TimelineReport.Models;
using MethodLifeCycleItems;

internal class TimeLineReporterBuilder
{
    internal TimeLineReport CreateReport(IEnumerable<IMethodLifeCycleItem> itemsCollection)
    {
        var items = itemsCollection
            .OrderBy(x => x.TimeStamp)
            .ToArray();

        var idAttributeType = new TimeLineReportItemAttributeType
        {
            Name = "Id",
            Type = typeof(string)
        };

        var startThreadAttributeType = new TimeLineReportItemAttributeType
        {
            Name = "StartThreadId",
            Type = typeof(int)
        };

        var endThreadIdAttributeType = new TimeLineReportItemAttributeType
        {
            Name = "EndThreadId",
            Type = typeof(int)
        };

        var callerClassAttributeType = new TimeLineReportItemAttributeType
        {
            Name = "CallerClass",
            Type = typeof(string)
        };

        var callerMethodAttributeType = new TimeLineReportItemAttributeType
        {
            Name = "CallerMethod",
            Type = typeof(int)
        };

        var startTimeAttributeType = new TimeLineReportItemAttributeType
        {
            Name = "StartTime",
            Type = typeof(int)
        };

        var endTimeAttributeType = new TimeLineReportItemAttributeType
        {
            Name = "EndTime",
            Type = typeof(int)
        };


        var attributeTypes = new List<TimeLineReportItemAttributeType>
        {
            idAttributeType,
            startThreadAttributeType,
            endThreadIdAttributeType,
            callerClassAttributeType,
            callerMethodAttributeType,
            startTimeAttributeType,
            endTimeAttributeType
        };

        var threadInvokeSequences = new Dictionary<int, int>();

        var reportItems = new Dictionary<MethodCallInfo, TimeLineReportItem>();
        foreach (var item in items.OrderBy(x => x.TimeStamp))
        {
            var timestamp = item.TimeStamp;
            var itemMethodCallInfo = item.MethodCallInfo;

            if (item is MethodCallStart methodCallStart)
            {
                var threadId = item.ThreadId;
                if (!threadInvokeSequences.TryGetValue(threadId, out var threadSequence))
                {
                    threadSequence = threadInvokeSequences.Values.Any() ? threadInvokeSequences.Values.Max() : 0;
                    threadInvokeSequences[threadId] = ++threadSequence;
                }

                reportItems.Add(itemMethodCallInfo, new()
                {
                    Id = itemMethodCallInfo.Id,
                    StartThreadId = methodCallStart.ThreadId,
                    StartTime = timestamp,
                    CallerClass = itemMethodCallInfo.ClassType.Name,
                    CallerMethod = itemMethodCallInfo.MethodName,
                    StartThreadSequence = threadSequence,

                    Attributes =
                    {
                        new (timestamp, idAttributeType, itemMethodCallInfo.Id),
                        new (timestamp, callerClassAttributeType, itemMethodCallInfo.ClassType.Name),
                        new (timestamp, callerMethodAttributeType, itemMethodCallInfo.MethodName),
                        new (timestamp, startTimeAttributeType, $"{timestamp:dd/MM/yyyy hh:mm:ss.fff}"),
                        new (timestamp, startThreadAttributeType, methodCallStart.ThreadId),
                    }
                });


                continue;
            }

            if (item is MethodCallEnd methodCallEnd)
            {
                if (reportItems.TryGetValue(itemMethodCallInfo, out var reportItem))
                {
                    var threadId = item.ThreadId;
                    if (!threadInvokeSequences.TryGetValue(threadId, out var threadSequence))
                    {
                        threadSequence = threadInvokeSequences.Values.Any() ? threadInvokeSequences.Values.Max() : 0;
                        threadInvokeSequences[threadId] = ++threadSequence;
                    }

                    reportItem.EndThreadId = methodCallEnd.ThreadId;
                    reportItem.EndTime = timestamp;
                    reportItem.EndThreadSequence = threadSequence;

                    reportItem.Attributes.Add(new(timestamp, endTimeAttributeType, $"{timestamp:dd/MM/yyyy hh:mm:ss.fff}"));
                    reportItem.Attributes.Add(new(timestamp, endThreadIdAttributeType, methodCallEnd.ThreadId));
                }
            }

            if (item is LogEntryItem logEntryItem)
            {
                if (reportItems.TryGetValue(itemMethodCallInfo, out var reportItem))
                {
                    var attributeName = logEntryItem.Category;
                    var attributeType = attributeTypes.FirstOrDefault(x => Equals(x.Name, attributeName));
                    if (attributeType is null)
                    {
                        attributeType = new()
                        {
                            Name = attributeName,
                            Type = logEntryItem.Data?.GetType()
                        };

                        attributeTypes.Add(attributeType);
                    }


                    reportItem.Attributes.Add(new(timestamp, attributeType, logEntryItem.Data));
                }
            }
        }

        var minDate = items.First().TimeStamp;
        var maxDate = items.Last().TimeStamp;

        return new()
        {
            StartTime = minDate,
            EndTime = maxDate,
            Items = reportItems.Values,
            AttributeTypes = attributeTypes,
        };
    }
}
