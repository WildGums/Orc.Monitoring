﻿#pragma warning disable CTL0011
namespace Gum.Projects.Data.Performance.Reporters.Archive;

using System.Collections.Generic;
using System.Text;
using System;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Catel.Logging;
using System.Reflection;
using MethodLifeCycleItems;
using ReportOutputs;

/// <summary>
/// Generates a full report of the method calls.
/// </summary>
public sealed class FullReporter : IMethodCallReporter
{
    private static readonly ILog Log = LogManager.GetCurrentClassLogger();

    private readonly List<IMethodLifeCycleItem> _items = new();
    private readonly List<IReportOutput> _outputs = new();

    private MethodInfo _rootMethod;
    private string _prefix = GetPrefix(null);

    public string Name { get => "Full Report"; }
    public string FullName => Name;

    public MethodInfo RootMethod
    {
        get => _rootMethod;
        set => _rootMethod = value;
    }

    public IDisposable StartReporting(IObservable<ICallStackItem> callStack)
    {
        if (_rootMethod is null)
        {
            throw new InvalidOperationException("Unable to start reporting when root method is not set");
        }

        var compositeDisposable = new CompositeDisposable();

        compositeDisposable.Add(InitializeOutputs());

        _prefix = GetPrefix(_rootMethod?.Name);

        var appendItems = callStack.OfType<IMethodLifeCycleItem>().Subscribe(onNext: _items.Add);
        var publishSummary = callStack.Where(x => Equals(x, CallStackItem.Empty)).Subscribe(x => Publish());

        compositeDisposable.Add(appendItems);
        compositeDisposable.Add(publishSummary);

        return compositeDisposable;
    }

    private IDisposable InitializeOutputs()
    {
        var compositeDisposable = new CompositeDisposable();

        foreach (var reportOutput in _outputs)
        {
            compositeDisposable.Add(reportOutput.Initialize(this));
        }

        return compositeDisposable;
    }

    public IOutputContainer AddOutput<TOutput>(object parameter) where TOutput : IReportOutput, new()
    {
        var output = new TOutput();
        output.SetParameters(parameter);

        _outputs.Add(output);

        return this;
    }

    private void Publish()
    {
        var items = _items.ToList();
        _items.Clear();

        var sb = new StringBuilder();
        sb.AppendLine("=== PerformanceMonitor Report ===");
        sb.AppendLine($"Generated at: {DateTime.UtcNow:yyyy-MM-dd HH:mm:ss.fff}");
        sb.AppendLine();

        sb.AppendLine("**Method Call Details:**");
        var contextsByThread = new Dictionary<int, List<MethodCallInfo>>();

        foreach (var item in items.OrderBy(x => x.TimeStamp))
        {
            var context = item.MethodCallInfo;
            if (item is MethodCallEnd methodCallEnd)
            {
                sb.AppendLine(GenerateCallReport(methodCallEnd));
                continue;
            }

            if (item is LogEntryItem logEntryItem)
            {
                sb.AppendLine(GenerateCallReport(logEntryItem));
                continue;
            }

            if (item is not MethodCallStart methodCallStart)
            {
                continue;
            }

            sb.AppendLine(GenerateCallReport(methodCallStart));

            var startTreadId = methodCallStart.ThreadId;
            if (!contextsByThread.TryGetValue(startTreadId, out var threadContexts))
            {
                threadContexts = new();
                contextsByThread[startTreadId] = threadContexts;
            }

            threadContexts.Add(context);
        }

        sb.AppendLine();

        sb.AppendLine("**Call Stack Report:**");

        foreach (var (threadId, threadCallStacks) in contextsByThread)
        {
            sb.AppendLine($"Thread ID: {threadId}");

            foreach (var context in threadCallStacks.OrderBy(x => x.StartTime))
            {
                sb.AppendLine(
                    $"{new(' ', context.Level * 2)}{context.Id} {context.ClassType.Name}.{context.MethodName} - (Thread: {threadId}, Time: {context.StartTime:HH:mm:ss.fff}, Duration: {context.Elapsed.TotalMilliseconds:N1} ms)");
            }

            sb.AppendLine();
        }

        var report = sb.ToString();

        Log.Info($"{_prefix}PerformanceMonitor Report:{Environment.NewLine}{report}");
    }

    private string GenerateCallReport(MethodCallStart methodCallStart)
    {
        var methodCallInfo = methodCallStart.MethodCallInfo;

        return $"{_prefix} {methodCallInfo.Id} {methodCallInfo.ClassType.Name}.{methodCallInfo.MethodName} - Start (Thread: {methodCallStart.ThreadId}, Time: {methodCallStart.TimeStamp:HH:mm:ss.fff})";
    }

    private string GenerateCallReport(MethodCallEnd methodCallEnd)
    {
        var methodCallInfo = methodCallEnd.MethodCallInfo;

        return $"{_prefix} {methodCallInfo.Id} {methodCallInfo.ClassType.Name}.{methodCallInfo.MethodName} - End (Thread: {methodCallEnd.ThreadId}, Duration: {methodCallInfo.Elapsed.TotalMilliseconds:N1} ms)";
    }

    private string GenerateCallReport(LogEntryItem logEntryItem)
    {
        var methodCallInfo = logEntryItem.MethodCallInfo;

        return $"{_prefix} [Info] {methodCallInfo.Id} {methodCallInfo.ClassType.Name}.{methodCallInfo.MethodName} - {logEntryItem.Category}: {logEntryItem.Data}";
    }

    private static string GetPrefix(string methodName) =>
        methodName is null
            ? "[PerformanceMonitor] "
            : $"[PerformanceMonitor] {methodName}: ";

}
